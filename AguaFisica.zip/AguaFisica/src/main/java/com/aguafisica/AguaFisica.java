package com.aguafisica;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AguaFisica implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("aguafisica");

    private static boolean pode(ServerCommandSource src) {
        return src.hasPermissionLevel(2) || src.getServer().isSingleplayer();
    }

    private static void avisar(CommandContext<ServerCommandSource> ctx, String msg) {
        ctx.getSource().sendFeedback(() -> Text.literal("[Água Física] " + msg), true);
    }

    private static LiteralArgumentBuilder<ServerCommandSource> mar(String nome, int intensidade, int correnteza) {
        return CommandManager.literal(nome).executes(ctx -> {
            Config.I.intensidade = intensidade;
            Config.I.correnteza = correnteza;
            Config.salvar();
            avisar(ctx, "Mar " + nome + " (ondas " + intensidade + "%, correnteza " + correnteza + "%)");
            return 1;
        });
    }

    @Override
    public void onInitialize() {
        Config.carregar();

        ServerTickEvents.END_WORLD_TICK.register(world -> Fisica.tick(world, world.iterateEntities()));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("aguafisica")
                        .requires(AguaFisica::pode)
                        .then(CommandManager.literal("mar")
                                .then(mar("calmo", 60, 60))
                                .then(mar("agitado", 180, 160))
                                .then(mar("tempestade", 280, 260))
                                .then(mar("extremo", 400, 400)))
                        .then(CommandManager.literal("intensidade")
                                .then(CommandManager.argument("percentual", IntegerArgumentType.integer(0, 400))
                                        .executes(ctx -> {
                                            Config.I.intensidade = IntegerArgumentType.getInteger(ctx, "percentual");
                                            Config.salvar();
                                            avisar(ctx, "Intensidade das ondas: " + Config.I.intensidade + "%");
                                            return 1;
                                        })))
                        .then(CommandManager.literal("correnteza")
                                .then(CommandManager.argument("percentual", IntegerArgumentType.integer(0, 400))
                                        .executes(ctx -> {
                                            Config.I.correnteza = IntegerArgumentType.getInteger(ctx, "percentual");
                                            Config.salvar();
                                            avisar(ctx, "Correnteza: " + Config.I.correnteza + "%");
                                            return 1;
                                        })))
                        .then(CommandManager.literal("perigo")
                                .then(CommandManager.argument("ligado", BoolArgumentType.bool())
                                        .executes(ctx -> {
                                            Config.I.perigo = BoolArgumentType.getBool(ctx, "ligado");
                                            Config.salvar();
                                            avisar(ctx, "Ondas gigantes derrubam passageiros: " + (Config.I.perigo ? "sim" : "não"));
                                            return 1;
                                        })))
                        .then(CommandManager.literal("status")
                                .executes(ctx -> {
                                    avisar(ctx, "ondas " + Config.I.intensidade + "% | correnteza " + Config.I.correnteza
                                            + "% | perigo " + (Config.I.perigo ? "sim" : "não"));
                                    return 1;
                                }))));

        LOGGER.info("[Água Física] Pronto.");
    }
}
