package com.aguafisica;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class AguaFisicaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // O barco que o jogador pilota é simulado no cliente dele, então a onda também age aqui.
        ClientTickEvents.END_WORLD_TICK.register(world -> Fisica.tick(world, world.getEntities()));
    }
}
